/**
 * @mainpage Student and course function demonstration
 *  
 * The book function demonstration shows how multiple functions in the book 
 * library work, including:
 * - printing an array of students in a course
 * - printing the top student
 * - printing an array of students that pass
 * 
 * @file main.c
 * @author Catherine Jiang
 * @date April 11, 2022
 * @brief Runs demonstration code for course and student.
 * 
 */ 

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * Generates an array of 8 random student names, id, and grades for a course named "MATH101"
 * and prints the information of the top student and students that pass
 * 
 */
int main()
{
  srand((unsigned) time(NULL));

  //creates a course called "MATH101"
  Course *MATH101 = calloc(1, sizeof(Course)); //allocates memory for one course
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //generates an array of students
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //prints all students in the course
  print_course(MATH101);

  //Determines and prints the top student
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //Determines and prints the students that pass 
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}