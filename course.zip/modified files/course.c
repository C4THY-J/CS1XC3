/**
 * @file course.c
 * @author Catherine Jiang
 * @date April 11, 2022
 * @brief Course library for managing courses, including definitions of 
 *        Course functions.
 *
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/** 
 * Adds a new student into array of students for one course
 * 
 * @param course a course 
 * @param student the student to be added.
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); //allocates a new memory for a student
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //resizes memory block to accommodate a new student
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * Prints the name, code, total number of students, and students' information of one course
 * 
 * @param course a course.
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/** 
 * Calculates the student with the highest average
 * 
 * @param course a course.
 * @return student
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * Determines which students pass the course and adds student to list
 * 
 * @param course a course 
 * @param total_passing array of students that pass
 * @return array of students that pass
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}