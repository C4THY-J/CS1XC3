 /**
 * @file student.h
 * @author Catherine Jiang
 * @date April 11, 2022
 * @brief Student library for managing students, including student type definition 
 *        and student functions.
 *
 */

/**
* Student type stores a student with fields first name, last name, 
* id, and grades.
*/
typedef struct _student 
{ 
  char first_name[50]; /**< student's first name */
  char last_name[50]; /**< student's last name */
  char id[11]; /**< student's id */
  double *grades; /**< list of student's grades */
  int num_grades; /**< number of grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
